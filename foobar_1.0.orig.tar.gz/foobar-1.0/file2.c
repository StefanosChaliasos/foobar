#include <stdio.h>

void fun2();

int main()
{
	fun2();
	return 0;
}

void fun2() {
	printf("bar\n");
}
