#include <stdio.h>

void fun1();

int main()
{
	fun1();
	return 0;
}

void fun1() {
	printf("foo\n");
}
